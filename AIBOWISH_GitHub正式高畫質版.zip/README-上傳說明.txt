AIBOWISH 愛寶願所｜GitHub + Vercel 正式高畫質版

請在 GitHub 的 aibowish_site repository 上傳「這個資料夾裡的內容」：
- index.html
- vercel.json
- assets 資料夾（內含 logo.jpg、story1.jpg、story2.jpg、story3.jpg、story4.jpg）

四張故事圖片皆為原始定案檔抽出的高畫質 JPEG：
story1.jpg：爸爸的最後一次陪伴
story2.jpg：阿布離開一個月了
story3.jpg：小墨離開一個星期了
story4.jpg：帥黑的故事

上傳完成後按 Commit changes。
Vercel 已連接此 GitHub repository，理論上會自動觸發部署。
